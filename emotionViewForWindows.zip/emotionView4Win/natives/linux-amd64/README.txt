This folder contains deprecated plain native libraries for platform linux-amd64, please use the native JAR files in the jar folder.
